═══════════════════════════════════════════════════════════════════════
🏛️  ATELIER MATEMÁTICO — DISTRIBUCIÓN PORTABLE PARA LINUX
    Nai Systems © 2026 · Cero Electron · Silicio Nativo
═══════════════════════════════════════════════════════════════════════

INSTRUCCIONES DE USO:
1. Descomprime este archivo en cualquier directorio de tu usuario.
2. Ejecuta directamente el script lanzador:
     ./atelier-matematico.sh
3. El lanzador detectará automáticamente tu acelerador gráfico WebGL
   (Chromium/Chrome/Brave/Edge en modo ventana nativa o Firefox).

COMPILACIÓN DE EJECUTABLE NATIVO GTK3/WEBKIT (OPCIONAL):
Si deseas un binario ELF nativo compilado en tu propio kernel:
1. Instala las dependencias en tu distribución:
     Debian/Ubuntu: sudo apt install build-essential libgtk-3-dev libwebkit2gtk-4.1-dev
     Fedora:        sudo dnf install gcc gtk3-devel webkit2gtk4.1-devel
     Arch Linux:    sudo pacman -S base-devel gtk3 webkit2gtk-4.1
2. Entra al directorio src/ y compila:
     cd src && make
3. El binario quedará en bin/atelier-matematico-bin y el lanzador lo usará
   como primera opción preferente.

═══════════════════════════════════════════════════════════════════════
