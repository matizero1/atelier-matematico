#!/usr/bin/env bash
# Lanzador Autónomo de Atelier Matemático en Linux
set -e

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INDEX_FILE="$DIR/index.html"

# 1. Si existe binario nativo GTK3/WebKit2GTK compilado, ejecutarlo directamente
if [ -x "$DIR/bin/atelier-matematico-bin" ]; then
    exec "$DIR/bin/atelier-matematico-bin" "$@"
fi

# 2. Buscar motores de renderizado con aceleración WebGL por hardware
CHROME_FLAGS="--app=file://$INDEX_FILE --window-size=1400,900 --enable-features=VaapiVideoDecoder,CanvasOopRasterization --ignore-gpu-blocklist --enable-gpu-rasterization --enable-zero-copy"

for browser in google-chrome google-chrome-stable chromium chromium-browser brave-browser microsoft-edge-stable vivaldi; do
    if command -v "$browser" >/dev/null 2>&1; then
        exec "$browser" $CHROME_FLAGS "$@"
    fi
done

# 3. Fallback a Firefox en modo ventana
if command -v firefox >/dev/null 2>&1; then
    exec firefox --new-window "file://$INDEX_FILE" "$@"
fi

# 4. Fallback al visualizador predeterminado del sistema (xdg-open)
if command -v xdg-open >/dev/null 2>&1; then
    exec xdg-open "$INDEX_FILE"
fi

echo "Error: No se encontró ningún visualizador WebGL compatible (Chrome, Chromium, Firefox, xdg-open)."
exit 1
