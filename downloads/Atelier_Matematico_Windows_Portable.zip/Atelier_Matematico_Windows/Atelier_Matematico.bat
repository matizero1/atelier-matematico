@echo off
title Atelier Matematico - Estacion de Trabajo Soberana
setlocal

set "APP_DIR=%~dp0"
set "INDEX_PATH=%APP_DIR%index.html"

:: 1. Buscar Microsoft Edge (presente en 100% de Windows 10/11) y lanzar en modo App dedicada
where msedge.exe >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    start "" msedge.exe --app="file://%INDEX_PATH%" --window-size=1400,900 --disable-features=Translate
    exit /b 0
)

:: 2. Buscar Google Chrome si Edge no está en PATH
where chrome.exe >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    start "" chrome.exe --app="file://%INDEX_PATH%" --window-size=1400,900
    exit /b 0
)

:: 3. Buscar Brave Browser
where brave.exe >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    start "" brave.exe --app="file://%INDEX_PATH%" --window-size=1400,900
    exit /b 0
)

:: 4. Fallback al navegador predeterminado
start "" "%INDEX_PATH%"
exit /b 0
