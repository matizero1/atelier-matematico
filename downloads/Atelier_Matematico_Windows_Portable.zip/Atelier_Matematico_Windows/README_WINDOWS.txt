═══════════════════════════════════════════════════════════════════════
🏛️  ATELIER MATEMÁTICO — DISTRIBUCIÓN PORTABLE PARA WINDOWS (X64)
    Nai Systems © 2026 · Cero Electron · Direct3D 12 Nativo
═══════════════════════════════════════════════════════════════════════

INSTRUCCIONES DE USO:
1. Extrae este archivo ZIP en cualquier carpeta (ej. C:\AtelierMatematico).
2. Haz doble clic en "Atelier_Matematico.bat" o "Launch_Silent.vbs".
3. La aplicación se abrirá como una ventana de escritorio independiente,
   con aceleración por hardware Direct3D 12 y 100% desconectada de Internet.

COMPILACIÓN NATIVA .EXE (OPCIONAL):
Si dispones de MinGW o Visual Studio C++, puedes generar el ejecutable .exe:
1. Entra a la carpeta src\
2. Ejecuta build_mingw.bat o build_msvc.bat
3. Se generará Atelier_Matematico.exe en la raíz de la carpeta.

═══════════════════════════════════════════════════════════════════════
