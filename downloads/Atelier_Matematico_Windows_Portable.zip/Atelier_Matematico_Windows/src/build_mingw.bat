@echo off
gcc -O3 -mwindows main_windows.c -o ..\Atelier_Matematico.exe
echo Compilacion finalizada en ..\Atelier_Matematico.exe
