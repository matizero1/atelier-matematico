@echo off
cl /O2 /W3 main_windows.c /link /SUBSYSTEM:WINDOWS /OUT:..\Atelier_Matematico.exe
echo Compilacion finalizada en ..\Atelier_Matematico.exe
